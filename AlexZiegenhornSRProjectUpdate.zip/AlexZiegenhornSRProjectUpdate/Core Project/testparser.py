def main():

	text = '|testinggg'

	parse1 = text.split('|')

	print(parse1)
	print(parse1[0])

if __name__ == '__main__':
	main()